## Responsive Remote Job Website Using HTML CSS & Javascript

### [⏯ Watch On Youtube](https://youtu.be/kgk04s142Jo)

![thumbnail](thumbnail.png)

----------