# Responsive Meditation Website Using HTML CSS & Javascript

### [🔗 Visit Live Demo](https://cods-medi.netlify.app/)

### [⏯ Watch On Youtube](https://youtu.be/NXxGO3g8sNs)

![thumbnail](thumbnail.png)

----------