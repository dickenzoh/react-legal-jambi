## Responsive Real Estate Website Using HTML SASS & Javascript

### [🔗 Visit Live Demo](https://cods-besnik.netlify.app/)

### [⏯ Watch On Youtube](https://youtu.be/pp1TFz7z_1k)


![thumbnail](thumbnail.png)

----------
