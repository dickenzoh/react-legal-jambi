*,
*::before,
*::after {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
:root {
  --btn-bg: rgb(109, 80, 240);
  --btn-hover-bg: rgb(97, 64, 243);
  --btn-shadow: rgba(85, 54, 223, 0.8);
}
html {
  font-size: 62.5%;
}
.container {
  max-width: 114rem;
  margin: 0 auto;
}