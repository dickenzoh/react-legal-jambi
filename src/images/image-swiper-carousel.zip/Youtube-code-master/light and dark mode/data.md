```html
@import url('https://fonts.googleapis.com/css2?family=Rubik:wght@400;500;600;700;900&display=swap');
  font-family: 'Rubik', sans-serif;
    :root {
  --nav-height: 6rem;
  --primary: #3e54cf;
  --black: #090429;
  --white: #fff;
  transition: background 0.5s cubic-bezier(0.075, 0.82, 0.165, 1),
    color 0.5s cubic-bezier(0.075, 0.82, 0.165, 1);}  

    A dark theme displays dark surfaces across the majority of a UI.
    It's designed to be a supplemental mode to a default (or light)
    theme 
    
    <script
      type="module"
      src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"
    ></script>
    <script
      nomodule
      src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"
    ></script>
```