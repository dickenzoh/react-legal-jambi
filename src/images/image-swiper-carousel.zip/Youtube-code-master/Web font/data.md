https://ionic.io/ionicons
https://boxicons.com/
https://remixicon.com/