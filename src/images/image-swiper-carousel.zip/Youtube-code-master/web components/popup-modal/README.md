# Animated Popup Modal Using HTML CSS & Javascript
![thumbnail](thumbnail.png)
[Watch On Youtube](https://youtu.be/SiFf0vsoyuc)
----------
