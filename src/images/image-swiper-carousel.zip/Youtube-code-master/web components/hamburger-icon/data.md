```css
*,
*::after,
*::before {
  margin: 0;
  padding: 0;
  box-sizing: inherit;
}
:root {
  --bg: #2f2371;
  --icon: #efedfc;
  --transition: all 0.5s ease-in-out;
}
html {
  font-size: 62.5%;
  scroll-behavior: smooth;
}
```