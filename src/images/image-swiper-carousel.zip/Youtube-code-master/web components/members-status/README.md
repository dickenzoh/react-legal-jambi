## Members Status Representation Design Using HTML & CSS

[📽 Watch On Youtube](https://youtu.be/cG6YqM84EUI)

![thumbnail](thumbnail.png)

------------------------
