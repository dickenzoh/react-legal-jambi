Home

Products

Products

 Team dashboard
 Monitor your metrics.

 Limitless segmentation
 Surface hidden trends.

 Group analytics
 Learn about your users

 Interactive reports
 Measure B2B account health.

Use cases

 Convert
 Analyze conversion rates.

 Engage
 Measure active usage.

 Retain
 Find retention drivers.

 Grow
 Grow your user base faster.

Resources

 Blog
 The latest industry news.

 Customer stories
 Learn how our customers.

 Video tutorials
 New features and techniques.

 Documentation
 All the boring stuff.

Company

 About us
 Learn about our story.

 Press
 News and press resources.

  We’re hiring!
 Careers
 Join our team!

 Legal
 All the boring stuff.

Resources
Pricing

Log in
Sign up

```html
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
```

```css
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500&display=swap');
*,
*::before,
*::after {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  text-decoration: none;
  list-style-type: none;
}

:root {
  --primary: #7F56D9;
  --secondary: #F4EBFF;
  --text-primary: #101828;
  --text-secondary: #667085;
  --badge-bg: #ECFDF3;
  --badge-text: #027A48;
  --white: #fff;
  --dropdown-bg: rgb(252, 253, 251);
  --shadow: rgba(32, 7, 65, 0.14);
  --container: 124rem;
  --nav-height: 7rem;
}

html {
  font-family: 'Inter', sans-serif;
  font-size: 62.5%;
  font-style: normal;
}

body {
  font-size: 1.6rem;
}

.container {
  max-width: var(--container);
  margin: 0 auto;
  padding: 0 1rem;
}
```