--bg:#ececf0;
--card-bg:#FBFBFB;
--black:#1E2021;
--white:#ffffff;

Forester Subaru
$25,195

XV Range Subaru
$44,220

Subaru Liberty
$44,770

Pajero Range
$35,000

Mirage Range
$16,290

Mitsubishi Lancer
$9,000

MERCEDES-BENZ
$200,000

ACURA ILX
$27,300

Lexus RX-350

$45,320
