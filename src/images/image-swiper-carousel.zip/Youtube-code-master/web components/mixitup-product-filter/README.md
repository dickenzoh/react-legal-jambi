## Product Filter Using Mixitup | Javascript

[Watch On Youtube](https://youtu.be/VE4sCmqiYmQ)

![thumbnail](thumbnail.png)

------------------------
