# Responsive Infinite Image slider | ( Part 3 ) Bug Fixing | Javascript
![thumbnail](thumbnail.jpg)
[Watch On Youtube](https://youtu.be/fLw4cJjlS1s)